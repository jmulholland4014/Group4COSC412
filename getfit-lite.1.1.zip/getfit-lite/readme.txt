=== Organic Lite ===

Contributors: Alexathemes
Requires at least: WordPress 4.4  
Tested up to: WordPress 5.4.1
Requires PHP: 5.2.6
Stable tag: 1.1.2
Version: 1.1.2
License: GPLv3 or later  
License URI: http://www.gnu.org/licenses/gpl-3.0.html  
Tags: one-column, two-columns, right-sidebar, custom-background, custom-header, custom-menu, featured-images, full-width-template, theme-options, threaded-comments, custom-logo, blog

== Description ==

Organic nature WordPress theme is created for represent the beautiful nature sites it help you make world’s environment cleaner and save the nature. This them has unique design and flexible options will make it best in a class. You can create any sort of Environment website, like a website for a ecology preserving movement, Green Earth organization, any sort of organic life project, animals saving fundraiser etc. This theme uses the latest HTML5 and CSS3 technologies. Theme is compatible with WordPress 4.0 and higher. This theme is fully responsive and well perform with all the resolutions also it is compatible with the latest version of WordPress and most popular plugins like contact form 7, woocommerce etc.
 
== Theme Resources == 

Theme is Built using the following resource bundles.

1 - All js that have been used are within folder /js of theme.
        jQuery Nivo Slider
	Copyright 2012, Dev7studios, under MIT license
	http://nivo.dev7studios.com


2 - Roboto Slab- https://fonts.google.com/specimen/robotoslab?selection.family=RobotoSlab
	License: Distributed under the terms of the Apache License, version 2.0 http://www.apache.org/licenses/LICENSE-2.0.html

3 - Font Awesome - https://fontawesome.com
         Font License:
         ---------------
	 Applies to all desktop and webfont files in the following directory: font-awesome/fonts/.
	 License: SIL OFL 1.1
	 URL: http://scripts.sil.org/OFL

	 Code License:
         ---------------
	 Applies to all CSS and LESS files in the following directories: font-awesome/css/, font-awesome/less/, and font-awesome/scss/.
	 License: MIT License
	 URL: http://opensource.org/licenses/mit-license.html

4 - 	Images used from Pixabay.
	Pixabay provides images under CC0 license 
	(https://creativecommons.org/about/cc0)	

	Slider:
	------
	https://pixabay.com/en/oranges-fruits-orange-tree-1117628/


4 - Based on Underscores http://underscores.me/, (C) 2012-2015 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)

/*-----------------------------------------------------------------------------------*/
/* Copyright */
/*-----------------------------------------------------------------------------------*/

Organic Lite WordPress Theme, Copyright 2020
Organic Lite is distributed under the terms of the GNU GPL

This is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see < http://www.gnu.org/licenses/ >

Organic Pro version
==========================================================
Organic pro version is compatible with GPL licensed.


For any help you can mail us at support[at]alexathemes.net

== Changelog ==

== 1.0 ==
i) Intial version Release


== 1.1 ==
i) Changed screenshot size and fixed some issues.

== 1.1.1 ==
i) Added escape functions and translation file.

== 1.1.2 ==
i) Added skip to content button and color option for footer.