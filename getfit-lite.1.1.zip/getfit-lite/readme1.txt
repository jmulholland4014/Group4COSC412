=== Getfit Lite ===

Contributors: Alexathemes
Requires at least: WordPress 4.4  
Tested up to: WordPress 5.4.1
Requires PHP: 5.2.6
Stable tag: 1.1
Version: 1.1
License: GPLv3 or later  
License URI: http://www.gnu.org/licenses/gpl-3.0.html  
Tags: one-column, two-columns, right-sidebar, custom-background, custom-header, custom-menu, featured-images, full-width-template, theme-options, threaded-comments, custom-logo, blog

== Description ==

GetFit is an modern, elegant, minimal gym WordPress theme specially built for gym, fitness center and fitness trainer. This theme built  for people who have no website building experience who need quick and easy way to setup website. This theme is comes with few theme options in customizer where you can easily manage all the options in just one click. This is fully responsive and comapatible with the latest version of WordPress, woocommmerce and contact form 7.
 
== Theme Resources == 

Theme is Built using the following resource bundles.

1 - All js that have been used are within folder /js of theme.
        jQuery Nivo Slider
	Copyright 2012, Dev7studios, under MIT license
	http://nivo.dev7studios.com


2 - Montserrat - https://fonts.google.com/specimen/robotoslab?selection.family=RobotoSlab
	License: Distributed under the terms of the Apache License, version 2.0 http://www.apache.org/licenses/LICENSE-2.0.html


4 - 	Images used from Pixabay.
	Pixabay provides images under CC0 license 
	(https://creativecommons.org/about/cc0)	

	Slider:
	------
	https://pixabay.com/en/barbell-bodybuilding-effort-1839087/


4 - Based on Underscores http://underscores.me/, (C) 2012-2015 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)

/*-----------------------------------------------------------------------------------*/
/* Copyright */
/*-----------------------------------------------------------------------------------*/

Getfit Lite WordPress Theme, Copyright 2018
Getfit Lite is distributed under the terms of the GNU GPL

This is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see < http://www.gnu.org/licenses/ >

Getfit Pro version
==========================================================
Getfit pro version is compatible with GPL licensed.


For any help you can mail us at support[at]alexathemes.net

== Changelog ==

== 1.0 ==
i) Intial version Release

== 1.1 ==
i) Added skip to content button and made few change of theme layout.