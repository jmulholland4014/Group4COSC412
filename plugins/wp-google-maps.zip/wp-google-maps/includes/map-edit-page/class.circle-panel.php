<?php

namespace WPGMZA;

class CirclePanel extends FeaturePanel
{
	public function __construct($map_id)
	{
		FeaturePanel::__construct($map_id);
	}
}