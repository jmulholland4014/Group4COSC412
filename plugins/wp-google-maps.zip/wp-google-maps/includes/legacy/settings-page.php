<?php

// Deprecated in 8.1.0