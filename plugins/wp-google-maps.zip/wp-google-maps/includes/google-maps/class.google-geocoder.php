<?php

// Deprecated as of 7.11.42 - May be reinstated in the future