declare class ResizeSensor {
    constructor(element: (Element | Element[]), callback: Function);
}

export = ResizeSensor;
